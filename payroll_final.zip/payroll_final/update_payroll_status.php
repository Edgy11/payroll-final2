<?php
/**
 * AJAX Endpoint: Update Payroll Status
 * Updates the status of a payroll record
 */

require_once 'includes/config.php';
require_once 'includes/auth.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payrollId = isset($_POST['payroll_id']) ? (int)$_POST['payroll_id'] : 0;
    $status = isset($_POST['status']) ? sanitize($_POST['status']) : '';
    
    // Validate inputs
    if ($payrollId <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid payroll ID']);
        exit;
    }
    
    // Validate status value
    $allowedStatuses = ['Draft', 'Approved', 'Paid'];
    if (isAdmin2()) {
        // admin2 can only mark as Paid
        $allowedStatuses = ['Paid'];
    }
    if (!in_array($status, $allowedStatuses)) {
        echo json_encode(['success' => false, 'message' => 'Invalid status value']);
        exit;
    }
    
    // Update the status
    $stmt = $conn->prepare("UPDATE payroll SET status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->bind_param("si", $status, $payrollId);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Status updated successfully',
            'payroll_id' => $payrollId,
            'new_status' => $status
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $conn->error
        ]);
    }
    
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>